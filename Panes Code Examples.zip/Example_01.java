/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 * Label()
 * Label(String)
 * Label(String, Graphic Node)
 */
import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

public class Example_01 extends Application {

  @Override
  public void start(Stage primaryStage) {

    // Image in ImageView
    ImageView us = new ImageView(new Image("image/us-map.gif"));
    // ImageView in Label - Uses newline
    Label lb1 = new Label("US\n50 States", us);
    // Label frame color
    lb1.setStyle("-fx-border-color: blue; -fx-border-width: 3");
    // Set Node Position
    lb1.setContentDisplay(ContentDisplay.BOTTOM);
    // Set fill to BLUE
    lb1.setTextFill(Color.BLUE);
    
    Circle circle = new Circle(50, 50, 25);
    circle.setFill(Color.color(Math.random(), Math.random(),
        Math.random()));
    // Circle in Label
    Label lb2 = new Label("Circle", circle);
    lb2.setContentDisplay(ContentDisplay.TOP);
    lb2.setTextFill(Color.RED);

    Rectangle rectangle = new Rectangle(10, 10, 50, 25);
    rectangle.setFill(Color.color(Math.random(), Math.random(),
        Math.random()));
    // Rectangle in Label
    Label lb3 = new Label("Retangle", rectangle);
    lb3.setContentDisplay(ContentDisplay.RIGHT);
    
    Ellipse ellipse2 = new Ellipse(50, 50, 50, 25);
    ellipse2.setFill(Color.color(Math.random(), Math.random(),
        Math.random()));
    // Ellipse in Label
    Label lb4 = new Label("Ellipse", ellipse2);
    lb4.setContentDisplay(ContentDisplay.LEFT);

    Ellipse ellipse3 = new Ellipse(50, 50, 50, 25);
    ellipse3.setFill(Color.color(Math.random(), Math.random(),
        Math.random()));
    ellipse3.setStroke(Color.color(Math.random(), Math.random(),
        Math.random()));
    // ellipse.setFill(Color.WHITE);
    ellipse3.setFill(Color.color(Math.random(), Math.random(),
        Math.random()));
    StackPane stackPane = new StackPane();
    stackPane.getChildren().addAll(ellipse3, new Label("JavaFX"));


    Label lb5 = new Label("A pane inside a label", stackPane); 
    lb5.setTextFill(Color.color(Math.random(), Math.random(),
        Math.random()));
    lb5.setContentDisplay(ContentDisplay.BOTTOM);
    
    // To Horizontal Box
    HBox pane = new HBox(20);
    pane.getChildren().addAll(lb1, lb2, lb3, lb4, lb5);

    Scene scene = new Scene(pane, 650, 150);
    primaryStage.setTitle("LabelWithGraphic");
    primaryStage.setScene(scene);
    primaryStage.show();
  }

   public static void main(String[] args) {
    launch(args);
  }
}
