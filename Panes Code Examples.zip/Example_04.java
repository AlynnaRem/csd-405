/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *        
 * Button
 * Up, Right, Down, Left
 *
 * And
 *
 * CheckBox to Change Text Attributes
 * ITALIC REGULAR BOLD
 *
 *  0, 1 or 2 selected
 *
 * And
 *
 * Radio Box to Change Color
 * ToggleGroup
 *
 * Only one Selected Because of ToggleGroup
 */
import javafx.geometry.Insets;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class Example_04 extends Example_03 {
  @Override // Override the getPane() method in the super class
  protected BorderPane getPane() {

    // Example_03 Pane that gets Example_02 Pane
    BorderPane pane = super.getPane();
    
    VBox paneForRadioButtons = new VBox(20);
    paneForRadioButtons.setPadding(new Insets(5, 5, 5, 5)); 
    paneForRadioButtons.setStyle("-fx-border-color: green");
    paneForRadioButtons.setStyle
      ("-fx-border-width: 2px; -fx-border-color: green");
    RadioButton rbRed = new RadioButton("Red");
    RadioButton rbGreen = new RadioButton("Green");
    RadioButton rbBlue = new RadioButton("Blue");
    paneForRadioButtons.getChildren().addAll(rbRed, rbGreen, rbBlue);
    // Pervious Center, Bottom, Right, now Left
    pane.setLeft(paneForRadioButtons);

    /*
     * Logical Error if ToggleGroup not Used
     * or
     * ToggleGroupr Created however 
     *  no Buttons set to Toggle Group
     */  
    ToggleGroup group = new ToggleGroup();
    rbRed.setToggleGroup(group);
    rbGreen.setToggleGroup(group);
    rbBlue.setToggleGroup(group);
    
    rbRed.setOnAction(e -> {
      if (rbRed.isSelected()) {
        text.setFill(Color.RED);
      }
    });
    
    rbGreen.setOnAction(e -> {
      if (rbGreen.isSelected()) {
        text.setFill(Color.GREEN);
      }
    });

    rbBlue.setOnAction(e -> {
      if (rbBlue.isSelected()) {
        text.setFill(Color.BLUE);
      }
    });
    
    return pane;
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
