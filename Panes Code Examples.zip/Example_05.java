/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *        
 * Button
 * Up, Right, Down, Left
 *
 * And
 *
 * CheckBox to Change Text Attributes
 * ITALIC REGULAR BOLD
 *
 *  0, 1 or 2 selected
 *
 * And
 *
 * Radio Box to Change Color
 * ToggleGroup
 *
 * Only one Selected Because of ToggleGroup
 * 
 * Text Field to Change Data String
 * 
 */
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

public class Example_05 extends Example_04 {

  @Override
  protected BorderPane getPane() {

    // Example_04 Pane that gets Example_03 Pane that gets Example_02 Pane
    BorderPane pane = super.getPane();
    
    BorderPane paneForTextField = new BorderPane();
    paneForTextField.setPadding(new Insets(5, 5, 5, 5)); 
    paneForTextField.setStyle("-fx-border-color: green");
    paneForTextField.setLeft(new Label("Enter a new message: "));
    
    TextField tf = new TextField();
    tf.setAlignment(Pos.BOTTOM_RIGHT);
    paneForTextField.setCenter(tf);
    // Pervious Center, Bottom, Right, Left, now Top
    pane.setTop(paneForTextField);
    
    tf.setOnAction(e -> text.setText(tf.getText()));
    
    return pane;
  }

  public static void main(String[] args) {
    launch(args);
  }
}
