/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 * A "String" is-a String
 */
public class Example_2_11{

  public static void main(String[] args){

    System.out.println("\"Test Test Test\" = " + "Test Test Test".length());

    System.out.println();
  }
}