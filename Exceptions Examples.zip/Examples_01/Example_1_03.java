/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 * No Exception is Thrown
 *
 */
public class Example_1_03{

  public static void main(String[] args){

    System.out.println(123.0 / 4.0);
    System.out.println(123.0 / 3.0);
    System.out.println(123.0 / 2.0);
    System.out.println(123.0 / 1.0);
    System.out.println(123.0 / 0.0); // Outputs as Infinity
  }
}